////////////////////////////////////////////////////////////////////////////////
//
// (C) Andy Thomason 2011
//
// Box2D sample

#ifdef WIN32
#define _CRT_SECURE_NO_WARNINGS 1
// This is the "GL extension wrangler"
// Note: you will need to use the right version of glew32s.lib (32 bit vs 64 bit)
#define GLEW_STATIC
#include "GL/glew.h"

// This is the "GL utilities" framework for drawing with OpenGL
#define FREEGLUT_STATIC
#define FREEGLUT_LIB_PRAGMAS 0
#include "GL/glut.h"
#include "AL/al.h"
#include "AL/alc.h"
#else
// please advise for Mac settings:
#include "GLUT/glut.h"
#include "AL/al.h"
#include "AL/alc.h"
#endif

#include <list>
#include <stdio.h>
#include <math.h>
#include <assert.h>

#include <vector.h>
#include <matrix.h>

#include <shader.h>

#include <file_manager.h>
#include <texture_manager.h>
#include <sound_manager.h>

#include <Box2D/Box2D.h>

// player class using box2d
class player {
	b2Body *body;
	GLuint *texture_;
	GLuint mvrght1, mvrght2, mvlft1, mvlft2;
	b2PolygonShape shape;
	float umax_;

public:
	player() { body = 0; }
	bool grounded;

	void init(b2World &world, float cx, float cy, float hx, float hy, float density, float umax) {
		grounded = false;
		
		b2BodyDef def;
		def.position.Set(cx, cy);
		def.angle = 0;
		def.type = density ? b2_dynamicBody : b2_staticBody;

		body = world.CreateBody(&def);
		body->SetFixedRotation(true);

		shape.SetAsBox(hx, hy);
		b2FixtureDef fixture;
		fixture.density = density;
		fixture.friction = 1.0f;
		fixture.shape = &shape;
		body->CreateFixture(&fixture);

		mvlft1 = texture_manager::new_texture("assets/player.tga", 0, 0, 28, 35);
		mvrght1 = texture_manager::new_texture("assets/player.tga", 0, 35, 28, 35);

		texture_ = &mvrght1;
		umax_ = umax;
	}

	void draw(shader &shader) {
		if (!body) {
			return;
		}

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, *texture_);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		// set the uniforms
		shader.render();

		b2Vec2 position = body->GetPosition();
		float32 angle = body->GetAngle();

		int count = shape.GetVertexCount();
		float vertices[4*4];
		float *p = vertices;
		float c = cosf(angle);
		float s = sinf(angle);
		assert(count == 4);
		static const float u[] = { 0, 1, 1, 0 };
		static const float v[] = { 0, 0, 1, 1 };
		for (int i = 0; i != count; ++i) {
			b2Vec2 vtx = shape.GetVertex(i);
			float x = position.x + vtx.x * c - vtx.y * s;
			float y = position.y + vtx.x * s + vtx.y * c;
			p[0] = x;
			p[1] = y;
			p[2] = u[i] * umax_;
			p[3] = v[i];
			p += 4;
		}

		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)vertices );
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(vertices + 2) );
		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(2);

		// kick the draw
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	}

	b2Body *return_body() { return body; };

	void jump()
	{
		b2Vec2 force = b2Vec2(0.0f, 7.0f);
		b2Vec2 point = body->GetPosition();
		body->ApplyLinearImpulse(force, point);
		this->grounded = false;
	}

	void move(bool mv_rght)
	{
		b2Vec2 force;
		if(mv_rght) {
			force = b2Vec2(0.5f, 0.0f);
			texture_ = &mvrght1;
		}
		else {
			force = b2Vec2(-0.5f, 0.0f);
			texture_ = &mvlft1;
		}
		b2Vec2 point = body->GetPosition();
		body->ApplyLinearImpulse(force, point);
	}

	bool is_fallen()
	{
		if(body->GetPosition().y < -20.0f)
			return true;
		else
			return false;
	}
};

// key class using box2d
class key {
	b2Body *body1, *body2;
	b2Joint *spring;
	GLuint texture_;
	b2PolygonShape shape1, shape2;
	float umax_;

public:
	key() { body1 = 0; body2 = 0; }

	void init(b2World &world, float cx, float cy, float hx, float hy, float umax) {		
		// create key
		b2BodyDef def1;
		def1.position.Set(cx, cy);
		def1.angle = 0;
		def1.type = b2_dynamicBody;

		body1 = world.CreateBody(&def1);
		body1->SetFixedRotation(true);

		shape1.SetAsBox(hx, hy);
		b2FixtureDef fixture1;
		fixture1.friction = 1.0f;
		fixture1.density = 0;
		fixture1.shape = &shape1;
		body1->CreateFixture(&fixture1);

		// create base
		b2BodyDef def2;
		def2.position.Set(cx, cy - 2.0f);
		def2.angle = 0;
		def2.type = b2_kinematicBody;

		body2 = world.CreateBody(&def2);
		body2->SetFixedRotation(true);

		shape2.SetAsBox(0.5f, 0.5f);
		b2FixtureDef fixture2;
		fixture2.friction = 1.0f;
		fixture2.shape = &shape2;
		body2->CreateFixture(&fixture2);
	
		// create spring
		b2PrismaticJointDef j_def;
		j_def.Initialize(body2, body1, body2->GetWorldCenter(), b2Vec2 (0, 1.0f));
		j_def.lowerTranslation = -1.0f;
		j_def.upperTranslation = 0;
		j_def.enableLimit = true;
		j_def.maxMotorForce = 18.0f;
		j_def.motorSpeed = 18.0f;
		j_def.enableMotor = true;
         
        spring = world.CreateJoint(&j_def);

		texture_ = texture_manager::new_texture("assets/key.tga", 0, 0, 27, 20);

		umax_ = umax;
	}

	void draw(shader &shader) {
		if (!body1 || ! body2) {
			return;
		}

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture_);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		// set the uniforms
		shader.render();

		b2Vec2 position = body1->GetPosition();
		float32 angle = body1->GetAngle();

		int count = shape1.GetVertexCount();
		float vertices[4*4];
		float *p = vertices;
		float c = cosf(angle);
		float s = sinf(angle);
		assert(count == 4);
		static const float u[] = { 0, 1, 1, 0 };
		static const float v[] = { 0, 0, 1, 1 };
		for (int i = 0; i != count; ++i) {
			b2Vec2 vtx = shape1.GetVertex(i);
			float x = position.x + vtx.x * c - vtx.y * s;
			float y = position.y + vtx.x * s + vtx.y * c;
			p[0] = x;
			p[1] = y;
			p[2] = u[i] * umax_;
			p[3] = v[i];
			p += 4;
		}

		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)vertices );
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(vertices + 2) );
		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(2);

		// kick the draw
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	}

	bool is_pressed() {
		if(body1->GetPosition().y < 2.2f)
			return true;
		else
			return false;
	}
};

// main game class: one instance only
class game_class : public b2ContactListener
{
	shader texture_shader_;
	GLint viewport_width_;
	GLint viewport_height_;
	ALuint buffers[256];

	GLuint gameworld;

	char keys[256];
	char prev_keys[256];

	b2World box2d_world;
	b2Body *trump_outline;

	player player_;
	key trump_keys[3];

	bool trump_sound;

	void play_sound() {
		if(!trump_sound) {
			char name[2];
			name[0] = '1';
			name[1] = 0;

			for(int i = 0; i < 3; i++) {
				if(trump_keys[i].is_pressed())
					name[0] = '1' + i + 1;
			}
			sound_manager::play(vec4(0, 0, 0, 0), name);
			trump_sound = true;
		}
	}

	void draw_world(shader &shader) {
		
		// draw keys
		for(int i = 0; i < 3; i++) {
			trump_keys[i].draw(texture_shader_);
		}

		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, gameworld);
		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		// set the uniforms
		shader.render();

		float vertices[] = {
			-15.0f, -5.0f, 0.0f, 0.0f,
			15.0f, -5.0f, 1.0f, 0.0f,
			15.0f, 5.0f, 1.0f, 1.0f,
			-15.0f, 5.0f, 0.0f, 1.0f
		};

		glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)vertices );
		glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, 4*sizeof(float), (void*)(vertices + 2) );
		glEnableVertexAttribArray(0);
		glEnableVertexAttribArray(2);

		// kick the draw
		glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

		// draw player
		player_.draw(texture_shader_);
	}

	void simulate() {
		memcpy(prev_keys, keys, sizeof(prev_keys));
		
		// player movement
		if(player_.grounded) {
			if(keys ['w']) {
				player_.jump();
			}
			if(keys['a'] || keys [37])
					player_.move(0);
			if(keys['d'] || keys [39])
				player_.move(1);
		}

		if(player_.is_fallen()) {
			char name[2];
			name[0] = '5';
			name[1] = 0;
			sound_manager::play(vec4(0, 0, 0, 0), name);
			player_.init(box2d_world, -10.0f, 10.0f, 0.5f, 0.5f, 1.0f, 1);
		}

		box2d_world.Step(1.0f/30, 6, 2);
	}

	void render() {
		simulate();

		// clear the frame buffer and the depth
		glClearColor(1, 1, 1, 1);
		glViewport(0, 0, viewport_width_, viewport_height_);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		draw_world(texture_shader_);

		// swap buffers so that the image is displayed.
		// gets a new buffer to draw a new scene.
		glutSwapBuffers();
	}

	// event called every time we begin a contact
	void BeginContact(b2Contact* contact) {
		player_.grounded = true;
	}

	game_class() : box2d_world(b2Vec2(0, -9.8f))
	{
		box2d_world.SetContactListener(this);
		memset(keys, 0, sizeof(keys));
		memset(prev_keys, 0, sizeof(prev_keys));

		sound_manager::add_buffers("assets/labels.txt", "assets/sounds.wav");

		// set up a simple shader to render the emissve color
		texture_shader_.init(
			// just copy the position attribute to gl_Position
			"varying vec2 uv_;"
			"attribute vec3 pos;"
			"attribute vec2 uv;"
			"void main() { gl_Position = vec4(pos * 0.05, 1); uv_ = uv; }",

			// just copy the color attribute to gl_FragColor
			"varying vec2 uv_;"
			"uniform sampler2D texture;"
			"void main() { gl_FragColor = texture2D(texture, uv_); }"
			//"void main() { gl_FragColor = vec4(1, 0, 0, 1); }"
			);

		// set up trumpet
		trump_sound = false;
		gameworld = texture_manager::new_texture("assets/trumpet.tga", 0, 0, 601, 208);

		b2BodyDef bd;
		trump_outline = box2d_world.CreateBody(&bd);

		b2EdgeShape shape;

		b2FixtureDef fd;
		fd.shape = &shape;
		fd.density = 0;
		fd.friction = 0.6f;

		float trump_verts_1[6] = {
			-15.0f, 1.3f,
			-7.8f, 1.3f,
			-7.8f, 2.0f,
		};

		for(int i = 0; i < 4;) {
			shape.Set(
				b2Vec2(trump_verts_1[i], trump_verts_1[i+1]),
				b2Vec2(trump_verts_1[i+2], trump_verts_1[i+3])
				);
				trump_outline -> CreateFixture(&fd);
				i+=2;
		}

		float trump_verts_2[8] = {
			-2.8f, 2.0f,
			-2.8f, 1.3f,
			8.0f, 1.3f,
			15.0f, 3.0f
		};

		for(int i = 0; i < 6;) {
			shape.Set(
				b2Vec2(trump_verts_2[i], trump_verts_2[i+1]),
				b2Vec2(trump_verts_2[i+2], trump_verts_2[i+3])
				);
				trump_outline -> CreateFixture(&fd);
				i+=2;
		}

		// setup keys
		trump_keys[0].init(box2d_world, -6.75f, 2.75f, 0.6f, 0.5f, 1);
		trump_keys[1].init(box2d_world, -5.25f, 2.75f, 0.6f, 0.5f, 1);
		trump_keys[2].init(box2d_world, -3.75f, 2.75f, 0.6f, 0.5f, 1);

		// setup player
		player_.init(box2d_world, -10.0f, 10.0f, 0.5f, 0.5f, 1.0f, 1);
	}

	// The viewport defines the drawing area in the window
	void set_viewport(int w, int h) {
		float ratio = (float) w / h;
		viewport_width_ = w;
		viewport_height_ = h * ratio;
	}

	void set_key(int key, int value) {
		keys[key & 0xff] = value;
	}

public:
	// a singleton: one instance of this class only!
	static game_class &get()
	{
		static game_class singleton;
		return singleton;
	}

	// interface from GLUT
	static void reshape(int w, int h) { get().set_viewport(w, h); }
	static void display() { get().render(); }
	static void timer(int value) { glutTimerFunc(30, timer, 1); glutPostRedisplay(); }
	static void key_down(unsigned char key, int x, int y) {
		if(key == 32)
			get().play_sound();
		else if(key == 27)
			exit(0);
		else
			get().set_key(key, 1);
	}
	static void key_up(unsigned char key, int x, int y) {
		if(key == 32) {
			sound_manager::stop();
			get().trump_sound = false;
		}
		else
			get().set_key(key, 0);
	}
};

// boilerplate to run the sample
int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_RGBA|GLUT_DEPTH|GLUT_DOUBLE);
	glutInitWindowSize(800, 800);
	glutCreateWindow("game");

#ifdef WIN32
	glewInit();
	if (!glewIsSupported("GL_VERSION_2_0") )
	{
		printf("OpenGL 2 is required!\n");
		return 1;
	}
#endif

	glutDisplayFunc(game_class::display);
	glutReshapeFunc(game_class::reshape);
	glutKeyboardFunc(game_class::key_down);
	glutKeyboardUpFunc(game_class::key_up);
	glutTimerFunc(30, game_class::timer, 1);
	glutMainLoop();
	return 0;
}
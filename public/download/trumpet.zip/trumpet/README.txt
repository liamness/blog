Liam Duffy - Goldsmiths University 2013

Controls are; W to jump, A and D to move left and right, and you press the spacebar to 'play' the trumpet.
L-system viewer by Liam Duffy
Produced at Goldsmiths University in 2012-2013 academic year

Controls:
WASD for directional movement
Click and drag for rotation
Arrows to change angle

Number keys (1-5) to change iteration
Function keys (1-6) to read config files
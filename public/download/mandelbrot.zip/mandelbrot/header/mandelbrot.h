#include <d3d9.h>
#include <d3dx9.h>
#include <map>
#include <string>

using namespace std;


#define KEY_PLUS			0xBD
#define KEY_MINUS			0xBB
#define KEY_LEFT			0x25
#define KEY_UP				0x26
#define KEY_RIGHT			0x27
#define KEY_DOWN			0x28
#define KEY_RESET			0x72
#define KEY_NORM			0x6E
#define KEY_O				0x4F
#define KEY_P				0x50



//==============================================================================
// Class Complex
//==============================================================================
class complex{
	//the real and imaginary components of the complex numbers
	float re_, im_;
public:
	complex ();
	complex (float re, float im);
	void mandelbrot_operation(complex c);
	float half_abs();
	float get_re();
	float get_im();
};

struct pixel{
	char b, g, r, a;
};
struct rgb{
	int b, g, r;
};

//==============================================================================
// Class Mandelbrot
//==============================================================================
class mandelbrot{
	float re_min_, re_max_, im_min_, im_max_;

	enum {
		overall_iter_max = 1000,
		rgb_max = 9
	};
	int iter_max;

	int pallette_r[overall_iter_max];
	int pallette_g[overall_iter_max];
	int pallette_b[overall_iter_max];

	rgb key_colours[rgb_max];
	int c_max;

	int extract_int(size_t start, size_t end, string str);
	
	//File no.
	int f_number;
	enum {file_max = 99};
	enum {file_min = 1};
public:
	void init();

	void create_pallette();
	bool load_pallette(int n);
	void load_next();
	void load_prev();

	void set_iterations(int iteration);

	void zoom(float percent);
	void rel_zoom(float x_adj1, float x_adj2, float y_adj1, float y_adj2);
	void norm_axes(float ratio);
	void translate(float tX, float tY);

	void update(int width, int height, LPDIRECT3DTEXTURE9 &texture);
};
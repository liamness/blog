////////////////////////////////////////////////////////////////////////////////




// ---------- rtvsD3dApp.h ----------

/*!

\file rtvsD3dWinLite.h
\brief interface for the rtvsD3dApp class
\author Gareth Edwards

*/


#ifndef _rtvsD3dApp_
#define _rtvsD3dApp_


#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000




// ---------- include ----------

#include <windows.h>
#include <stdio.h>
#include <d3d9.h>
#include <d3dx9.h>
#include "../header/vector.h"

#include "../header/mandelbrot.h"



////////////////////////////////////////////////////////////////////////////////




// ---------- FVF - Flexible Vertex Formats ----------

struct LineVertex{
    float x , y, z;
 enum FVF{
        FVF_Flags = D3DFVF_XYZ
    };
};
struct QuadVertex
{
    float x, y, z;
    float nx, ny, nz;
	DWORD diffuse;
    float tu, tv;

    enum FVF
    {
        FVF_Flags = D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_DIFFUSE | D3DFVF_TEX1
    };
};

// ---------- rtvsD3dApp class interface ----------

class rtvsD3dApp{
	// ---- properties ----
	DWORD	_id;
public:
	// ---- properties ----
	ID3DXFont*				pFont;
	D3DCOLOR				fontCol;
	LPDIRECT3DVERTEXBUFFER9	pAxisVertexBuffer;
	LPDIRECT3DVERTEXBUFFER9	pQuadVertexBuffer;
	LPDIRECT3DVERTEXBUFFER9	pVectVertexBuffer;
	DWORD					numAxisLines;
	DWORD					numQuadTriangles;
	DWORD					numVectLines;
	LPDIRECT3DTEXTURE9		pTexture;
	LPDIRECT3DTEXTURE9		texture_a;
	LPDIRECT3DTEXTURE9		texture_b;
	D3DMATERIAL9			lineMtrl;
	D3DMATERIAL9			vectorStartMtrl;
	D3DMATERIAL9			vectorResultMtrl;
	D3DMATERIAL9			quadMtrl;
	D3DLIGHT9				sunLight;
	D3DLIGHT9				backLight;
	DWORD					currentKeyClicked;
	DWORD					previousKeyClicked;
	DWORD					vectorLineCount;
	float					fSpinX;
	float					fSpinY;
	char*					vectorName;

	// harry and liam's Variables
	mandelbrot mandel;

	int wind_width, wind_height;
	float old_mousepos_x, old_mousepos_y;
	float cur_mousepos_x, cur_mousepos_y;
	bool click_down, click_up;

	bool quad, quadSolid;

	bool keyboard_stopper;
	int mandel_width, mandel_height;

	// ---- methods ----

	// constructor/destructor
	rtvsD3dApp (int);

	// framework
	bool cleanup	();
	bool cleanupDX	(LPDIRECT3DDEVICE9);
	bool display	(LPDIRECT3DDEVICE9);
	bool setup		();
	bool setupDX	(LPDIRECT3DDEVICE9);

	// gui
	bool updateKeyboard ();

};

////////////////////////////////////////////////////////////////////////////////

#endif // _rtvsD3dApp_





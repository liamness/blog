////////////////////////////////////////////////////////////////////////////////




// ---------- rtvsD3dApp.cpp ----------

/*!

\file rtvsD3dApp.cpp
\brief Implementation of the rtvsD3dApp class
\author Gareth Edwards

*/




// ---------- include ----------

#include "../header/rtvsD3dApp.h"
#include "../header/vector.h"
#include "../header/vector.h"




////////////////////////////////////////////////////////////////////////////////




// ---------- constructor ----------

/*!

\brief constructor
\author Gareth Edwards

\param int (id of this instance)


*/

rtvsD3dApp::rtvsD3dApp (int id)
{

	// initialise
	ZeroMemory( this, sizeof(rtvsD3dApp) );

	// store id
	_id = id;

	// key clicked
	currentKeyClicked = 0;
	keyboard_stopper = false;

}




////////////////////////////////////////////////////////////////////////////////




// ---------- framework ----------




// ---------- framework : cleanup ----------

/*!

\brief framework : cleanup
\author Gareth Edwards

\return bool (TRUE if ok)

*/

bool rtvsD3dApp::cleanup ()
{

	// ok
	return true;

}




// ---------- framework : cleanup dx ----------

/*!

\brief framework : cleanup dx
\author Gareth Edwards

\param LPDIRECT3DDEVICE9	(device)

\return bool (TRUE if ok)

*/

bool rtvsD3dApp::cleanupDX (LPDIRECT3DDEVICE9 pd3dDevice)
{

	// ---- invalidate the font object ----

	if( pFont != NULL )
	{
		int nNewRefCount = pFont->Release();

		if( nNewRefCount > 0 )
		{
			static char strError[256];
			sprintf_s ( strError, 256,
				"The font object failed to cleanup properly.\n"
				"Release() returned a reference count of %d",
				nNewRefCount );
			MessageBox( NULL, strError, "ERROR", MB_OK | MB_ICONEXCLAMATION );
		}

		pFont = NULL;
	}


	// ---- invalidate the texture object ----

	if( pTexture != NULL )
	{
		int nNewRefCount = pTexture->Release();

		if( nNewRefCount > 0 )
		{
			static char strError[256];
			sprintf_s ( strError, 256,
				"The texture object failed to cleanup properly.\n"
				"Release() returned a reference count of %d",
				nNewRefCount );
			MessageBox( NULL, strError, "ERROR", MB_OK | MB_ICONEXCLAMATION );
		}

		pTexture = NULL;
	}


	// ---- invalidate the axis vertex buffer object ----

	if( pAxisVertexBuffer != NULL )
	{
		int nNewRefCount = pAxisVertexBuffer->Release();

		if( nNewRefCount > 0 )
		{
			static char strError[256];
			sprintf_s ( strError, 256,
				"The axis vertex buffer object failed to cleanup properly.\n"
				"Release() returned a reference count of %d",
				nNewRefCount );
			MessageBox( NULL, strError, "ERROR", MB_OK | MB_ICONEXCLAMATION );
		}
		pAxisVertexBuffer = NULL;
	}


	// ---- invalidate the quad vertex buffer object ----

	if( pQuadVertexBuffer != NULL )
	{
		int nNewRefCount = pQuadVertexBuffer->Release();

		if( nNewRefCount > 0 )
		{
			static char strError[256];
			sprintf_s ( strError, 256,
				"The quad vertex buffer object failed to cleanup properly.\n"
				"Release() returned a reference count of %d",
				nNewRefCount );
			MessageBox( NULL, strError, "ERROR", MB_OK | MB_ICONEXCLAMATION );
		}
		pQuadVertexBuffer = NULL;
	}


	// ---- invalidate the vector vertex buffer object ----

	if( pVectVertexBuffer != NULL )
	{
		int nNewRefCount = pVectVertexBuffer->Release();

		if( nNewRefCount > 0 )
		{
			static char strError[256];
			sprintf_s ( strError, 256,
				"The line vertex buffer object failed to cleanup properly.\n"
				"Release() returned a reference count of %d",
				nNewRefCount );
			MessageBox( NULL, strError, "ERROR", MB_OK | MB_ICONEXCLAMATION );
		}
		pVectVertexBuffer = NULL;
	}


	// ok
	return true;

}




// ---------- framework : display ----------

/*!

\brief framework : display
\author Gareth Edwards

\param LPDIRECT3DDEVICE9	(device)

\return bool (TRUE if ok)

*/

bool rtvsD3dApp::display (LPDIRECT3DDEVICE9 pd3dDevice)
{

	// clear backbuffers
	pd3dDevice->Clear( 0,
		NULL,
		D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
		D3DCOLOR_COLORVALUE(0.0f,0.0f,0.0f,0.0f),
		1.0f,
		0);


	// display flags
	quad = true;
	quadSolid = true;

	// set render states
	pd3dDevice->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);


	// check input
	updateKeyboard();

	//Change the config file
	if (currentKeyClicked==KEY_O){
		mandel.load_prev();
		mandel.update(mandel_width,mandel_height,pTexture);
	}
	else if (currentKeyClicked==KEY_P){
		mandel.load_next();
		mandel.update(mandel_width,mandel_height,pTexture);
	}

	//Select Iteration
	else if(currentKeyClicked >= 1 && currentKeyClicked <= 9) {
		mandel.set_iterations(currentKeyClicked*30);
		mandel.create_pallette();
		mandel.update(mandel_width,mandel_height,pTexture);
	}

	// movement
	else if(currentKeyClicked==KEY_LEFT) {
		mandel.translate(-0.25f, 0);
		mandel.update(mandel_width,mandel_height,pTexture);
	}
	else if(currentKeyClicked==KEY_RIGHT) {
		mandel.translate(0.25f, 0);
		mandel.update(mandel_width,mandel_height,pTexture);
	}
	else if(currentKeyClicked==KEY_DOWN) {
		mandel.translate(0, -0.25f);
		mandel.update(mandel_width,mandel_height,pTexture);
	}
	else if(currentKeyClicked==KEY_UP) {
		mandel.translate(0, 0.25f);
		mandel.update(mandel_width,mandel_height,pTexture);
	}


	//Change the zoom
	else if (currentKeyClicked==KEY_PLUS){
		mandel.zoom(2.0f);
		mandel.update(mandel_width,mandel_height,pTexture);
	}
	else if (currentKeyClicked==KEY_MINUS){
		mandel.zoom(-2.0f);
		mandel.update(mandel_width,mandel_height,pTexture);
	}

	// zoom to selection
	if (click_up) {
		if(old_mousepos_x > cur_mousepos_x) {
			int temp = old_mousepos_x;
			old_mousepos_x = cur_mousepos_x;
			cur_mousepos_x = temp;
		}
		else if(old_mousepos_y > cur_mousepos_y) {
			int temp = old_mousepos_y;
			old_mousepos_y = cur_mousepos_y;
			cur_mousepos_y = temp;
		}
		// check selection not made in error
		if(((cur_mousepos_x - old_mousepos_x) > 10) && ((cur_mousepos_y - old_mousepos_y) > 10)) {
			float x_adj1 = (float) (old_mousepos_x / wind_width);
			float x_adj2 = (float) 1.0f - (cur_mousepos_x / wind_width);
			float y_adj1 = (float) 1.0f - (cur_mousepos_y / wind_height);
			float y_adj2 = (float) (old_mousepos_y / wind_height);
			mandel.rel_zoom(x_adj1, x_adj2, y_adj1, y_adj2);
			mandel.update(mandel_width,mandel_height,pTexture);
			click_up = false;
		}
		else click_up = false;
	}

	// normalise axes
	if(currentKeyClicked == KEY_NORM) {
		mandel.norm_axes(wind_width/wind_height * 1.3f);
		mandel.update(mandel_width, mandel_height, pTexture);
	}

	// reset everything
	if(currentKeyClicked == KEY_RESET) {
		mandel.init();
		mandel.create_pallette();
		mandel.update(mandel_width, mandel_height, pTexture);
	}

	// IF quad THEN
	if (quad)
	{
		// display solid textured quad
		if (quadSolid)
		{
			pd3dDevice->SetMaterial( &quadMtrl );
			pd3dDevice->SetTexture( 0, pTexture );
			pd3dDevice->SetStreamSource( 0, pQuadVertexBuffer, 0, sizeof(QuadVertex) );
			pd3dDevice->SetFVF( QuadVertex::FVF_Flags );
			pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
			pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, numQuadTriangles );
		}

		// display wireframe quad
		if (click_down)
		{
			float x_min = (2.025f * old_mousepos_x / wind_width) - 1.0f;
			float x_max = (2.025f * cur_mousepos_x / wind_width) - 1.0f;
			float y_min = 1.0f - (2.1f * old_mousepos_y / wind_height);
			float y_max = 1.0f - (2.1f * cur_mousepos_y / wind_height);
			// ---- initialise quad vertex data ----
			QuadVertex quadVertices[] =
			{
				//    x      y      z     nx     ny     nz     d,   tu     tv
				{ x_max,  y_max,  0.0f,  0.0f,  0.0f,  1.0f,    0,  0.0f,  0.0f },
				{ x_min,  y_max,  0.0f,  0.0f,  0.0f,  1.0f,    0,  1.0f,  0.0f },
				{ x_max,  y_min, 0.0f,  0.0f,  0.0f,  1.0f,    0,  0.0f,  1.0f },
				{ x_min,  y_min, 0.0f,  0.0f,  0.0f,  1.0f,    0,  1.0f,  1.0f }
			};

			// ---- create quad vertex buffer ----
			pQuadVertexBuffer->Release();
			int numQuadVertices = sizeof(quadVertices) / ( sizeof(float) * 8 +  sizeof(DWORD));
			numQuadTriangles = numQuadVertices / 2;
			pd3dDevice->CreateVertexBuffer( numQuadVertices*sizeof(QuadVertex),
				D3DUSAGE_WRITEONLY,
				QuadVertex::FVF_Flags,
				//D3DPOOL_MANAGED, // does not have to be properly Released before calling IDirect3DDevice9::Reset
				D3DPOOL_DEFAULT,   // must be Released properly before calling IDirect3DDevice9::Reset
				&pQuadVertexBuffer, NULL );


			// ---- block copy into quad vertex buffer ----
			void *pVertices = NULL;
			pQuadVertexBuffer->Lock( 0, sizeof(quadVertices), (void**)&pVertices, 0 );
			memcpy( pVertices, quadVertices, sizeof(quadVertices) );
			pQuadVertexBuffer->Unlock();

			pd3dDevice->SetMaterial( &lineMtrl );
			pd3dDevice->SetTexture( 0, 0 );
			pd3dDevice->SetStreamSource( 0, pQuadVertexBuffer, 0, sizeof(QuadVertex) );
			pd3dDevice->SetFVF( QuadVertex::FVF_Flags );			
			pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
			pd3dDevice->DrawPrimitive( D3DPT_TRIANGLESTRIP, 0, numQuadTriangles );
		}

	// ---- initialise quad vertex data ----
		QuadVertex quadVertices[] =
		{
			//    x      y      z     nx     ny     nz     d,   tu     tv
			{  1.0f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,    0,  0.0f,  0.0f },
			{ -1.0f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,    0,  1.0f,  0.0f },
			{  1.0f,  -1.0f, 0.0f,  0.0f,  0.0f,  1.0f,    0,  0.0f,  1.0f },
			{ -1.0f,  -1.0f, 0.0f,  0.0f,  0.0f,  1.0f,    0,  1.0f,  1.0f }
		};

		// ---- create quad vertex buffer ----
		pQuadVertexBuffer->Release();
		int numQuadVertices = sizeof(quadVertices) / ( sizeof(float) * 8 +  sizeof(DWORD));
		numQuadTriangles = numQuadVertices / 2;
		pd3dDevice->CreateVertexBuffer( numQuadVertices*sizeof(QuadVertex),
			D3DUSAGE_WRITEONLY,
			QuadVertex::FVF_Flags,
			//D3DPOOL_MANAGED, // does not have to be properly Released before calling IDirect3DDevice9::Reset
			D3DPOOL_DEFAULT,   // must be Released properly before calling IDirect3DDevice9::Reset
			&pQuadVertexBuffer, NULL );


		// ---- block copy into quad vertex buffer ----
		void *pVertices = NULL;
		pQuadVertexBuffer->Lock( 0, sizeof(quadVertices), (void**)&pVertices, 0 );
		memcpy( pVertices, quadVertices, sizeof(quadVertices) );
		pQuadVertexBuffer->Unlock();

	}

	// ok
	return true;

}




// ---------- framework : setup ----------

/*!

\brief framework : setup
\author Gareth Edwards

\return bool (TRUE if ok)

*/

bool rtvsD3dApp::setup ()
{
	// setup a material for the lines
	ZeroMemory( &lineMtrl, sizeof(D3DMATERIAL9) );
	lineMtrl.Emissive.r = 0;
	lineMtrl.Emissive.g = 1.0f;
	lineMtrl.Emissive.b = 0;


	// setup a material for the textured quad
	ZeroMemory( &quadMtrl, sizeof(D3DMATERIAL9) );
	quadMtrl.Ambient.r = 1.0f;
	quadMtrl.Ambient.g = 1.0f;
	quadMtrl.Ambient.b = 1.0f;
	quadMtrl.Ambient.a = 1.0f;


	// ok
	return true;
}




// ---------- framework : setup dx ----------

/*!

\brief framework : setup dx
\author Gareth Edwards

\param LPDIRECT3DDEVICE9	(device)

\return bool (TRUE if ok)

*/

bool rtvsD3dApp::setupDX (LPDIRECT3DDEVICE9 pd3dDevice)
{
	// ---- create a texture object ----
	//D3DXCreateTextureFromFile( pd3dDevice, "image/baboon.jpg", &pTexture );
	//pTexture->Release();


	// procedure to setup mandelbrot class
	mandel_width = 768;
	mandel_height = 768;
	D3DXCreateTexture(pd3dDevice, mandel_width, mandel_height, 1, D3DUSAGE_DYNAMIC, D3DFMT_X8R8G8B8, D3DPOOL_DEFAULT, &pTexture);
	mandel.init();
	mandel.create_pallette();
	mandel.update(mandel_width, mandel_height, pTexture);


	// ---- set texture sampling states ----
	pd3dDevice->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
	pd3dDevice->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );


	// ---- FONT ----

	fontCol = D3DCOLOR_COLORVALUE(1,1,1,1);
	D3DXCreateFont(
		pd3dDevice,
		30,								// height in pixels
		0,								// width in pixels (0 for default)
		400,							// thickness, 0-1000 OR FW_THIN (100), FW_NORMAL (400), FW_BOLD (700), FW_HEAVY (900)
		0,								// number of MipMaps to create. 0 creates a full chain - no scaling use 1
		false,							// 0/1 - true/false, do you want Italics
		DEFAULT_CHARSET,				// character Set - (Arabic, Greek, etc)
		OUT_DEFAULT_PRECIS,				// how precisely the output must match the font
		ANTIALIASED_QUALITY,			// ANTIALIASED_QUALITY, DEFAULT_QUALITY, DRAFT_QUALITY, and PROOF_QUALITY
		DEFAULT_PITCH | FF_DONTCARE,	// font pitch 
		"Arial",						// name of the required font or "" for system best match
		&pFont);


	// ---- QUAD ----


	// ---- initialise quad vertex data ----
	QuadVertex quadVertices[] =
	{
		//    x      y      z     nx     ny     nz     d,   tu     tv
		{  1.0f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,    0,  0.0f,  0.0f },
		{ -1.0f,  1.0f,  0.0f,  0.0f,  0.0f,  1.0f,    0,  1.0f,  0.0f },
		{  1.0f,  -1.0f, 0.0f,  0.0f,  0.0f,  1.0f,    0,  0.0f,  1.0f },
		{ -1.0f,  -1.0f, 0.0f,  0.0f,  0.0f,  1.0f,    0,  1.0f,  1.0f }
	};

	// ---- create quad vertex buffer ----
	int numQuadVertices = sizeof(quadVertices) / ( sizeof(float) * 8 +  sizeof(DWORD));
	numQuadTriangles = numQuadVertices / 2;
	pd3dDevice->CreateVertexBuffer( numQuadVertices*sizeof(QuadVertex),
		D3DUSAGE_WRITEONLY,
		QuadVertex::FVF_Flags,
		//D3DPOOL_MANAGED, // does not have to be properly Released before calling IDirect3DDevice9::Reset
		D3DPOOL_DEFAULT,   // must be Released properly before calling IDirect3DDevice9::Reset
		&pQuadVertexBuffer, NULL );


	// ---- block copy into quad vertex buffer ----
	void *pVertices = NULL;
	pQuadVertexBuffer->Lock( 0, sizeof(quadVertices), (void**)&pVertices, 0 );
	memcpy( pVertices, quadVertices, sizeof(quadVertices) );
	pQuadVertexBuffer->Unlock();


	// ok
	return true;

}




////////////////////////////////////////////////////////////////////////////////




// ---------- update keyboard ----------

/*!

\brief update keyboard
\author Gareth Edwards

\param rtvsD3dSdk::stage* (pointer to RTVS Stage)

\return bool (TRUE if key updated)

*/

bool rtvsD3dApp::updateKeyboard ()
{
	// get key clicked

	//Nu,bersd
	if(GetAsyncKeyState('1') & 0x8000f)
		currentKeyClicked = 1;
	else if(GetAsyncKeyState('2') & 0x8000f)
		currentKeyClicked = 2;
	else if(GetAsyncKeyState('3') & 0x8000f)
		currentKeyClicked = 3;
	else if(GetAsyncKeyState('4') & 0x8000f)
		currentKeyClicked = 4;
	else if(GetAsyncKeyState('5') & 0x8000f)
		currentKeyClicked = 5;
	else if(GetAsyncKeyState('6') & 0x8000f)
		currentKeyClicked = 6;
	else if(GetAsyncKeyState('7') & 0x8000f)
		currentKeyClicked = 7;
	else if(GetAsyncKeyState('8') & 0x8000f)
		currentKeyClicked = 8;
	else if(GetAsyncKeyState('9') & 0x8000f)
		currentKeyClicked = 9;
	else if(GetAsyncKeyState('0') & 0x8000f)
		currentKeyClicked = 0;

	//Plus and Minus
	else if((GetAsyncKeyState(VK_OEM_MINUS) & 0x8000f) || (GetAsyncKeyState(VK_ADD) & 0x8000f))
		currentKeyClicked = KEY_MINUS;
	else if((GetAsyncKeyState(VK_OEM_PLUS) & 0x8000f) || (GetAsyncKeyState(VK_SUBTRACT) & 0x8000f))
		currentKeyClicked = KEY_PLUS;

	//Arrow Keys
	else if(GetAsyncKeyState(VK_UP) & 0x8000f)
		currentKeyClicked = KEY_UP;
	else if(GetAsyncKeyState(VK_DOWN) & 0x8000f)
		currentKeyClicked = KEY_DOWN;
	else if(GetAsyncKeyState(VK_LEFT) & 0x8000f)
		currentKeyClicked = KEY_LEFT;
	else if(GetAsyncKeyState(VK_RIGHT) & 0x8000f)
		currentKeyClicked = KEY_RIGHT;

	// other keys
	else if(GetAsyncKeyState('R') & 0x8000f)
		currentKeyClicked = KEY_RESET;
	else if(GetAsyncKeyState('N') & 0x8000f)
		currentKeyClicked = KEY_NORM;
	else if(GetAsyncKeyState('P') & 0x8000f)
		currentKeyClicked = KEY_P;
	else if(GetAsyncKeyState('O') & 0x8000f)
		currentKeyClicked = KEY_O;

	//Buffer
	if (keyboard_stopper != true && currentKeyClicked!=0){
		keyboard_stopper = true;
	} else if (keyboard_stopper == true && currentKeyClicked==0) {
		keyboard_stopper = false;
	} else {
		currentKeyClicked = 0;
	}

	// ok*/
	return true;
}




////////////////////////////////////////////////////////////////////////////////


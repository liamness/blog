#include "../header/mandelbrot.h"

complex::complex (){
	re_ = 0;
	im_ = 0;
}
complex::complex (float re, float im){
	re_ = re;
	im_ = im;
}
void complex::mandelbrot_operation(complex c){
	float re_temp = (re_*re_) - (im_*im_) + c.get_re();
	im_ = 2 * re_ * im_ + c.get_im();
	re_ = re_temp;
}
float complex::half_abs(){
	return ((re_*re_) + (im_*im_));
}
float complex::get_re(){return re_;}
float complex::get_im(){return im_;}

/*void mandelbrot::init() {
	iter_max = 500;
	re_min_ = -2.5f;
	re_max_ = 1.0f;
	im_min_ = -1.0f;
	im_max_ = 1.0f;
}

void mandelbrot::create_pallette(){
	int split = iter_max/3;
	for (int i=0; i < split; i++){
		pallette_r[i] = 0;
		pallette_g[i] = 0;
		pallette_b[i] = ((float)i/split)*255;
	}
	for (int i=0; i < split; i++){
		pallette_r[split + i] = ((float)i/split)*255;
		pallette_g[split + i] = ((float)i/split)*128;
		pallette_b[split + i] = 255 - (((float)i/split)*255);
	}
	for (int i=0; i < split; i++){
		pallette_r[(2*split) + i] = 255;
		pallette_g[(2*split) + i] = 128 + (((float)i/split)*127);
		pallette_b[(2*split) + i] = 255;
	}
}*/

void mandelbrot::init(){
	iter_max = 200;

	re_min_ = -2.5f;
	re_max_ = 1.0f;
	im_min_ = -1.0f;
	im_max_ = 1.0f;

	f_number = 1;
	load_pallette(f_number);
}
/*
void mandelbrot::create_pallette(){
	int split = iter_max/3;
	for (int i=0; i < split; i++){
		pallette_r[i] = 0;
		pallette_g[i] = 0;
		pallette_b[i] = ((float)i/split)*255;
	}
	for (int i=0; i < split; i++){
		pallette_r[split + i] = ((float)i/split)*255;
		pallette_g[split + i] = ((float)i/split)*128;
		pallette_b[split + i] = 255 - (((float)i/split)*255);
	}
	for (int i=0; i < split; i++){
		pallette_r[(2*split) + i] = 255;
		pallette_g[(2*split) + i] = 128 + (((float)i/split)*127);
		pallette_b[(2*split) + i] = 255;
	}
}
*/

bool mandelbrot::load_pallette(int n){
	// temp variables
	char line[128];
	string str;
	bool success = false;
	
	//Create array of rgb values to store the key colour values. By default, they are black.
	for (int i = 0; i < rgb_max; i++){
		key_colours[i].r = 0;
		key_colours[i].g = 0;
		key_colours[i].b = 0;
	}
	//string fileName = "../config/config";
	string fileName = "configs/config";
	if (n<10){
		fileName += '0';
	}
	string number = to_string((long double)n);
	fileName+= number;
	fileName+= ".txt";

	//Open file in read mode
	FILE *lines = fopen(fileName.c_str(), "r");
	if (lines != NULL){
		c_max = 0;
		//Copy the contents of the file into line array.
		while (fgets(line, sizeof(line), lines)){
			//Convert to string, to get access to the nifty methods.
			string s(line);

			//Omitt all leading whitepaces (blanks, formfeeds, tabs)
			size_t start = s.find_first_not_of( " \f\t\v" );

			// Skip blank lines
			if (start == string::npos) continue;

			// Skip comments
			if (string("#").find(s [start]) != string::npos) continue;

			// Find the location of '='
			size_t end = s.find('=', start);
			// Continue only if '=' is found
			if (end != string::npos){
				// Extract the key value, omitting whitespaces.
				str = s.substr(start, end - start);
				str.erase( str.find_last_not_of(" \f\t\v" ) + 1);

				// Check to see if there's something left.
				if (str.empty()) continue;
				
				//Check to see if the first letter of the key is 'c'
				if (str.at(0)!='c')continue;

				//Erase the first character (the range starting at 0 with range 1.
				str.erase(0,1);

				//Convert the remainder of the key value into an integer.
				int c = atoi(str.c_str());

				//If that integer is not within 0 or 9, it means that the value is over the permitted amount, or the key contains data other than a number.
				if (c<0||c>rgb_max) continue;
				c_max = c_max > c ? c_max : c;

				//Re-use old begin and end variables to extract data, omitting leading and trailing blank spaces.
				start = s.find_first_not_of(" \f\n\r\t\v", end + 1);
				end   = s.find_last_not_of (" \f\n\r\t\v") + 1;

				//Commit to data
				str = s.substr( start, end - start );

				if (str.empty())continue;

				//Extract red value;
				start = 0;
				end = str.find_first_of(',');
				int red = extract_int(start,end,str);
				if (red==-1) continue;

				//Extract green value;
				start = str.find_first_of(',')+1;
				end = str.find_first_of(',', end+1);
				int green = extract_int(start,end,str);
				if (green==-1) continue;

				//Extract blue value;
				start = str.find_first_of(',', start +1)+1;
				end = str.find_first_of(',', end+1) == string::npos ? str.size() : str.find_first_of(',', end+1);
				int blue = extract_int(start,end,str);
				if (blue==-1) continue;

				key_colours[c].r = red;
				key_colours[c].g = green;
				key_colours[c].b = blue;

				success = true;
			}
		} //End-while
		//We've finished reading the document. First we check to see if at least one line was written correctly.
		if (success){
			create_pallette();
			return true;
		} else return false;
	}
	return false;
}

//Method: create_pallette
void mandelbrot::create_pallette(){
	float split = iter_max/(c_max);
	for (int c = 0; c < c_max; c++){
		for (int j = 0; j < split; j++){
			pallette_r[(int)(c*split)+j] = key_colours[c].r +((j/split) * (key_colours[c+1].r-key_colours[c].r));
			pallette_g[(int)(c*split)+j] = key_colours[c].g +((j/split) * (key_colours[c+1].g-key_colours[c].g));
			pallette_b[(int)(c*split)+j] = key_colours[c].b +((j/split) * (key_colours[c+1].b-key_colours[c].b));
		}
	}
}

int mandelbrot::extract_int(size_t start, size_t end, string str){
	//Validate input
	if (start == string::npos) return -1;
	if (end == string::npos) return -1;
	if (str.empty())return -1;

	//Create substring between start and end.
	string sub_str = str.substr(start, (end)-start);

	//Clear all blank spaces from the substring.
	int f = sub_str.find(" \f\r\t\v");
	while (f!=string::npos){
		f = sub_str.find(" \f\r\t\v");
		str.erase(f);
	}

	//Check if there's anything left
	if (sub_str.empty()) return -1;

	//Convert to integer
	int val = atoi(sub_str.c_str());

	//Check if the number is valid.
	if (val<0||val>255) return -1;

	//Return value
	return val;
}

// Method: read_next
void mandelbrot::load_next(){
	while (!load_pallette(++f_number))
		f_number = f_number >= file_max ? file_min-1 : f_number;
}

// Method: read_prev
void mandelbrot::load_prev(){
	while (!load_pallette(--f_number))
		f_number = f_number <= file_min ? file_max+1 : f_number;
}

void mandelbrot::set_iterations(int iteration){
	iter_max = iteration > overall_iter_max ? overall_iter_max : iteration;
}

void mandelbrot::zoom(float p){
	float re_half_ext = (re_max_ - re_min_)/2;
	float re_mid = re_min_ + re_half_ext;
	float re_scale = re_half_ext/p;
	re_max_ -= re_scale;
	re_min_ += re_scale;
	
	float im_half_ext = (im_max_ - im_min_)/2;
	float im_mid = im_min_ + (im_half_ext);
	float im_scale = im_half_ext/p;
	im_max_ -= im_scale;
	im_min_ += im_scale;
}

void mandelbrot::rel_zoom(float x_adj1, float x_adj2, float y_adj1, float y_adj2) {
	float re_size = (re_max_ - re_min_);
	re_min_ += re_size * x_adj1;
	re_max_ -= re_size * x_adj2;
	float im_size = (im_max_ - im_min_);
	im_min_ += im_size * y_adj1;
	im_max_ -= im_size * y_adj2;
}

void mandelbrot::norm_axes(float ratio) {
	float re_size = (re_max_ - re_min_);
	float im_size = (im_max_ - im_min_);
	float cur_ratio = re_size / im_size;
	if(cur_ratio - ratio > 0.1f) {
		float im_adj = re_size / ratio - im_size;
		im_max_ += im_adj / 2.0f;
		im_min_ -= im_adj / 2.0f;
	}
	else if(cur_ratio - ratio < -0.1f){
		float re_adj = im_size * ratio - re_size;
		re_max_ += re_adj / 2.0f;
		re_min_ -= re_adj / 2.0f;
	}
}

void mandelbrot::translate(float tX, float tY){
	float re_size = (re_max_ - re_min_);
	float im_size = (im_max_ - im_min_);
	re_min_ += re_size * tX;
	re_max_ += re_size * tX;
	im_min_ += re_size * tY;
	im_max_ += re_size * tY;
}

void mandelbrot::update(int width, int height, LPDIRECT3DTEXTURE9 &texture) {
	D3DLOCKED_RECT rect_temp;
	texture->LockRect(0, &rect_temp, NULL, D3DLOCK_DISCARD);
	pixel *pixelptr = (pixel *)rect_temp.pBits;

	double y0, x0;

	complex c, z;

	for (int iy = width; iy != 0; iy--){
		y0 = (((float)iy/height)*(im_max_-im_min_))+im_min_;

		for (int ix = height; ix != 0; ix--){
			x0 = (((float)ix/width)*(re_max_-re_min_))+re_min_;

			c = complex(x0,y0);
			z = complex(0,0);

			int n = 0;
			while ((z.half_abs() <= 2*2) && (n++ < iter_max)){
				z.mandelbrot_operation(c);
			}

			bool cond = n < iter_max;

			pixelptr->r = cond ? pallette_r[n] : 0; // blue channel
			pixelptr->g = cond ? pallette_g[n] : 0; // green channel
			pixelptr->b = cond ? pallette_b[n] : 0; // red channel
			pixelptr++; // move on pixel
		}
	}
	texture->UnlockRect(0);
}